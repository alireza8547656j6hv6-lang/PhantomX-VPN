package app.phantomx

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.BufferedReader
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

val PURPLE = Color.parseColor("#B26BFF")
val CYAN = Color.parseColor("#00E5FF")

/** One backend and one tunnel for the whole process, so VPN state survives the screen being recreated. */
object Core {
    var backend: GoBackend? = null
    var listener: ((Tunnel.State) -> Unit)? = null
    var t0 = 0L
    val tunnel: Tunnel = object : Tunnel {
        override fun getName() = "phantomx"
        override fun onStateChange(s: Tunnel.State) { listener?.invoke(s) }
    }
}

/** Purple matrix-rain background */
class Rain(c: Context) : View(c) {
    private val p = Paint().apply { color = PURPLE; textSize = 32f; typeface = Typeface.MONOSPACE }
    private val chars = "01<>/{}#%&ABCDEF"
    private var y = IntArray(0)
    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.parseColor("#05010F"))
        val cols = width / 26
        if (y.size != cols) y = IntArray(cols) { Random.nextInt(60) }
        for (i in 0 until cols) {
            for (k in 0 until 14) {
                p.alpha = (230 - k * 16).coerceAtLeast(0)
                cv.drawText(chars[Random.nextInt(chars.length)].toString(), i * 26f, (y[i] - k) * 34f, p)
            }
            y[i]++
            if (y[i] * 34 > height + 480) y[i] = -Random.nextInt(20)
        }
        postInvalidateDelayed(80)
    }
}

class MainActivity : Activity() {
    private lateinit var backend: GoBackend
    private lateinit var power: Button
    private lateinit var powerBg: GradientDrawable
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var console: TextView
    private lateinit var box: EditText
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var scanning = false
    private val tunnel: Tunnel get() = Core.tunnel
    private val idle = "↓ 0 KB   ↑ 0 KB   ⏱ 00:00:00"

    private val tick = object : Runnable {
        override fun run() {
            try {
                val s = backend.getStatistics(tunnel)
                val sec = (System.currentTimeMillis() - Core.t0) / 1000
                stats.text = "↓ ${fmt(s.totalRx())}   ↑ ${fmt(s.totalTx())}   ⏱ %02d:%02d:%02d".format(sec / 3600, sec / 60 % 60, sec % 60)
            } catch (e: Exception) { }
            h.postDelayed(this, 1000)
        }
    }

    private val listener: (Tunnel.State) -> Unit = { s ->
        if (!scanning) runOnUiThread {
            val up = s == Tunnel.State.UP
            applyState(up)
            log(if (up) "tunnel UP - traffic encrypted" else "tunnel DOWN")
        }
    }

    private fun applyState(up: Boolean) {
        status.text = if (up) "[ ONLINE ]" else "[ OFFLINE ]"
        status.setTextColor(if (up) CYAN else Color.RED)
        power.setTextColor(if (up) CYAN else PURPLE)
        powerBg.setStroke(7, if (up) CYAN else PURPLE)
        h.removeCallbacks(tick)
        if (up) {
            if (Core.t0 == 0L) Core.t0 = System.currentTimeMillis()
            h.post(tick)
        } else {
            Core.t0 = 0L
            stats.text = idle
        }
    }

    private fun fmt(b: Long) = when {
        b > 1073741824L -> "%.2f GB".format(b / 1073741824.0)
        b > 1048576L -> "%.1f MB".format(b / 1048576.0)
        else -> "%.0f KB".format(b / 1024.0)
    }

    private fun log(m: String) {
        runOnUiThread { console.append("[${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())}] $m\n") }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        backend = Core.backend ?: GoBackend(applicationContext).also { Core.backend = it }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        fun tv(t: String, sz: Float, c: Int = PURPLE) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(c); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
        }
        fun panel() = GradientDrawable().apply {
            setColor(Color.parseColor("#CC05010F")); setStroke(2, PURPLE); cornerRadius = 14f
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(PURPLE); typeface = Typeface.MONOSPACE; background = panel()
            setOnClickListener { f() }
        }
        val lp = { LinearLayout.LayoutParams(-1, -2).apply { setMargins(40, 18, 40, 0) } }
        fun row(a: View, d: View) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
            addView(d, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 8 })
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, 48) }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.logo); adjustViewBounds = true }, LinearLayout.LayoutParams(-1, -2))
        root.addView(tv("سازنده: علیرضا مقیاسی", 16f), lp())

        powerBg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#14052A")); setStroke(7, PURPLE) }
        power = Button(this).apply { text = "⚡"; textSize = 56f; setTextColor(PURPLE); background = powerBg; setOnClickListener { onPower() } }
        root.addView(power, LinearLayout.LayoutParams(300, 300).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = 24 })

        status = tv("[ OFFLINE ]", 20f, Color.RED).also { root.addView(it, lp()) }
        stats = tv(idle, 13f).also { root.addView(it, lp()) }
        console = TextView(this).apply {
            textSize = 11f; setTextColor(PURPLE); typeface = Typeface.MONOSPACE; setPadding(20, 16, 20, 16)
            minLines = 6; background = panel()
        }
        root.addView(console, lp())
        box = EditText(this).apply {
            hint = "[Interface] ... paste WireGuard config"; setHintTextColor(Color.parseColor("#6B4FA0"))
            setTextColor(Color.parseColor("#E9D5FF")); typeface = Typeface.MONOSPACE; textSize = 11f
            minLines = 5; gravity = Gravity.TOP; background = panel()
        }
        root.addView(box, lp())
        root.addView(row(btn("🔎 FASTEST") { scan() }, btn("☁ WARP") { warpAsk() }), lp())
        root.addView(row(btn("🌐 MY IP") { myIp() }, btn("📡 PING") { ping() }), lp())
        root.addView(btn("🗑 FORGET SAVED CONFIG") {
            box.setText("")
            getSharedPreferences("p", 0).edit().clear().apply()
            log("config wiped")
        }, lp())
        root.addView(tv("بدون ثبت‌نام  •  بدون لاگ  •  فقط کانفیگ روی خود گوشی می‌ماند", 12f), lp())

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        frame.addView(Rain(this).apply { alpha = 0.3f }, FrameLayout.LayoutParams(-1, -1))
        frame.addView(ScrollView(this).apply { addView(root) })

        // full-screen logo splash (tap to skip)
        val splash = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            setBackgroundColor(Color.BLACK)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        frame.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        // let the logo reach the very edges of the screen, including under the camera notch
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val hide = Runnable {
            splash.animate().alpha(0f).setDuration(600).withEndAction {
                frame.removeView(splash)
                window.decorView.systemUiVisibility = 0
            }
        }
        splash.setOnClickListener { h.removeCallbacks(hide); hide.run() }
        h.postDelayed(hide, 2200)

        box.setText(getSharedPreferences("p", 0).getString("cfg", ""))
        Core.listener = listener
        applyState(backend.getState(tunnel) == Tunnel.State.UP)
        log("PHANTOMX ready. no account, no logs. config stays on this phone only.")
    }

    override fun onDestroy() {
        if (Core.listener === listener) Core.listener = null
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun onPower() {
        val up = backend.getState(tunnel) == Tunnel.State.UP
        if (!up && box.text.isBlank()) warpAsk(true) else toggle()
    }

    private fun net(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        return c.inputStream.bufferedReader().readText()
    }

    private fun myIp() {
        Thread {
            try {
                val j = JSONObject(net("https://ipwho.is/"))
                log("IP ${j.getString("ip")} | ${j.optString("country")} ${j.optString("city")} | ${j.optJSONObject("connection")?.optString("isp")}")
            } catch (e: Exception) { log("IP check failed: ${e.message}") }
        }.start()
    }

    private fun ping() {
        Thread {
            try {
                val t = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 4000) }
                log("PING 1.1.1.1 = ${(System.nanoTime() - t) / 1000000} ms")
            } catch (e: Exception) { log("PING failed") }
        }.start()
    }

    private fun warpAsk(c: Boolean = false) {
        AlertDialog.Builder(this)
            .setMessage("This creates an anonymous Cloudflare WARP account on Cloudflare's servers (no personal data). Continue?")
            .setPositiveButton("YES") { _, _ -> getWarp(c) }
            .setNegativeButton("NO", null)
            .show()
    }

    private fun getWarp(q: Boolean) {
        log("requesting WARP config...")
        Thread {
            try {
                val cfg = warp()
                runOnUiThread { box.setText(cfg); if (q) toggle() }
                log("WARP config ready")
            } catch (e: Exception) { log("WARP failed: ${e.message}") }
        }.start()
    }

    private fun warp(): String {
        val kp = KeyPair()
        val c = URL("https://api.cloudflareclient.com/v0a2158/reg").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 15000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("CF-Client-Version", "a-6.3-2158")
        val body = JSONObject().put("key", kp.publicKey.toBase64()).put("install_id", "").put("fcm_token", "")
            .put("tos", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date()))
            .put("type", "Android").put("locale", "en_US")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val a = JSONObject(c.inputStream.bufferedReader().readText())
            .getJSONObject("config").getJSONObject("interface").getJSONObject("addresses")
        return "[Interface]\nPrivateKey = ${kp.privateKey.toBase64()}\nAddress = ${a.getString("v4")}/32, ${a.getString("v6")}/128\nDNS = 1.1.1.1, 1.0.0.1\nMTU = 1280\n\n" +
            "[Peer]\nPublicKey = bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = engage.cloudflareclient.com:2408\n"
    }

    private fun toggle() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 1) else go()
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        if (r == 1 && res == RESULT_OK) go()
    }

    private fun go() {
        val text = box.text.toString()
        Thread {
            try {
                val up = backend.getState(tunnel) == Tunnel.State.UP
                if (up) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                } else if (text.isBlank()) {
                    log("no config yet - tap the big button to get one")
                } else {
                    getSharedPreferences("p", 0).edit().putString("cfg", text).apply()
                    log("connecting...")
                    backend.setState(tunnel, Tunnel.State.UP, Config.parse(BufferedReader(StringReader(text))))
                }
            } catch (e: Exception) { log("ERROR: ${e.message}") }
        }.start()
    }

    private fun scan() {
        if (scanning) return
        val base = box.text.toString()
        if (!base.contains("Endpoint")) { log("get or paste a config first"); return }
        if (VpnService.prepare(this) != null) { toggle(); return }
        val eps = listOf("162.159.192.1:2408", "162.159.192.1:500", "162.159.193.1:2408", "162.159.195.1:4500",
            "188.114.97.1:2408", "188.114.99.1:500", "162.159.192.1:854", "engage.cloudflareclient.com:2408")
        val re = Regex("(?m)^Endpoint\\s*=.*\$")
        Thread {
            scanning = true
            var best: String? = null
            var bestMs = Long.MAX_VALUE
            try {
                for (ep in eps) {
                    try {
                        backend.setState(tunnel, Tunnel.State.UP, Config.parse(BufferedReader(StringReader(base.replace(re, "Endpoint = $ep")))))
                        val t = System.nanoTime()
                        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 3500) }
                        val ms = (System.nanoTime() - t) / 1000000
                        log("$ep = $ms ms")
                        if (ms < bestMs) { bestMs = ms; best = ep }
                    } catch (e: Exception) { log("$ep = fail") }
                    try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (e: Exception) { }
                }
            } finally { scanning = false }
            val b = best
            if (b != null) {
                runOnUiThread { box.setText(base.replace(re, "Endpoint = $b")); log("BEST: $b ($bestMs ms) - connecting"); toggle() }
            } else {
                log("no endpoint worked here - use your own server config")
            }
        }.start()
    }
}
